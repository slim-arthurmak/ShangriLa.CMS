//>>built
define("dojo/errors/CancelError",["./create"],function(_1){return _1("CancelError",null,null,{dojoType:"cancel"});});